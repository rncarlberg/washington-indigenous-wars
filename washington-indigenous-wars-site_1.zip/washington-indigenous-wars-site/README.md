# Washington Indigenous Wars — Static Site

This is a plain HTML/CSS rebuild of washingtonindianwars.com. No WordPress, no plugins, no database —
just files you can open, edit, or host anywhere.

## What's in this folder

```
index.html                          Home
time-line.html                      Time Line
pandemic-of-european-diseases.html  Effects of European Disease and Alcohol
language-beliefs-prophecies.html    Language, Beliefs, & Prophecies
kamiakin-hero.html                  Kamiakin Hero (landing page)
chapter-summaries.html              Kamiakin: The Last Hero of the Yakimas — Chapter Summaries
andrew-jackson-splawn.html          Andrew Jackson Splawn
lo-kout.html                        Chapter 18 "Speak of Lo-Kout"
bibliography.html                   Bibliography
css/styles.css                      Shared stylesheet (design system for the whole site)
images/                             Empty folder — see "Adding your images" below
```

## Try it right now

Double-click any `.html` file and it'll open in your browser. Every page already works and links to
every other page correctly — you can click through the whole site locally before it's hosted anywhere.

## Adding your images

The Home page currently loads images directly from your live WordPress site
(`washingtonindianwars.com/wp-content/uploads/...`) so you can see the finished design immediately. That
only works while WordPress is still running — once you take the site down, those images will break.

A few pages (Kamiakin Hero, Andrew Jackson Splawn, and Chapter 18 "Speak of Lo-Kout") reference images by
filename in the empty `images/` folder, since I wasn't able to pull those specific photos from the site.

**Before you go live, download these from your WordPress Media Library** (Media → Library, click each
image, then "Download file" or right-click → Save Image As) and save them into the `images/` folder using
these exact filenames:

| Save as this filename | Which photo |
|---|---|
| `kamiakin-yakama-chief.jpg` | The Kamiakin portrait (already used site-wide as the default share image) |
| `kamiakin-book-cover.jpg` | The Kamiakin book cover image on the Kamiakin Hero page |
| `andrew-jackson-splawn.jpg` | Splawn's portrait |
| `lo-kout-old-age.jpg` | Lo-Kout in old age |
| `theodore-winthrop.jpg` | Theodore Winthrop portrait |
| `george-wright.jpg` | Colonel George Wright portrait |

Once those are in place, do a find-and-replace across the HTML files, swapping the long
`https://washingtonindianwars.com/wp-content/uploads/...` URLs on the Home page for local paths like
`images/kamiakin-yakama-chief.jpg` — or just tell me you've added the files and I'll do that swap for you.

## The contact form

Plain HTML can't process form submissions on its own — there's no server behind it. Every page's footer
form currently points to a placeholder:

```html
<form class="contact-form" action="https://formspree.io/f/YOUR_FORM_ID" method="POST">
```

To make it work:
1. Go to [formspree.io](https://formspree.io) and create a free account.
2. Create a new form — it'll give you a unique form ID (looks like `mzbqwxyz`).
3. Replace `YOUR_FORM_ID` in that line, in every HTML file, with your real ID.

I'm happy to do this step for you once you have the ID — just paste it here.

## Hosting it

Once your images are in place, you have two easy, usually-free options:

- **Netlify or Cloudflare Pages:** drag the whole folder onto their upload page — no configuration
  needed. This is the simplest option and gives you a URL immediately, plus an easy way to connect your
  existing washingtonindianwars.com domain later.
- **Your existing Hostinger plan:** you don't need the WordPress product on Hostinger to host these files
  — a basic shared hosting plan works. Upload the contents of this folder (not the folder itself) to the
  `public_html` directory via Hostinger's File Manager or FTP.

## Making changes later

Come back to any Claude conversation, paste in the HTML file you want to change (or describe the change),
and ask for the edit — no WordPress login, no plugin panel, no "did it save" uncertainty. Since everything
is plain text, changes are exact and immediate.

## What was fixed in this rebuild

Compared to the live WordPress site, this version already has:
- No placeholder/lorem ipsum text anywhere
- The Bibliography link fixed (no more `/bibiliography/` typo)
- "Yakima" corrected to "Yakama" when referring to the tribe (place names like the Yakima River/Valley/
  County, and the historic book title *The Last Hero of the Yakimas*, are left as-is — that's the correct
  historical spelling for those)
- Typo fixes: "10,000–12,000 years," "measles epidemic," capitalized "European"
- Real, unique meta descriptions and social-share text for every page (nothing auto-truncated)
- All footnote-number artifacts (e.g. "35353535") cleaned out of the Chapter Summaries text

One thing I couldn't verify: the Bibliography page lists Rebecca Clarren's *The Cost of Free Land* as
published by Viking in 1985 — that date looks like it may have been copied from the Miller entry just
above it. Worth double-checking before this goes live.
